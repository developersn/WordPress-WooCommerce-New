﻿=== Woocommerce savano Gateway ===

author: savanoteam1 
URI: http://www.savano.co.ir/
Contributors: savanoteam1 
Tags: woocommerce,savano, iran,farsi,woocommerce persian,woocommerce,payment gateway,
Requires at least: 4.4
Tested up to: 4.9
Stable tag: trunk 

پرداخت اینترنتی با درگاه پرداخت آنلاین ساوانو 


== Description ==
**Woocommerce Savano Gateway** 
افزونه پرداخت آنلاین ساوانو این امکان فراهم می سازد تا به راحتی بتوانید برای پرداخت های فروشگاه ساز ووکامرس از آن استفاده کنید


= امکانات =

* قابلیت نمایش خطاه های درگاه پرداخت		 
* سازگار با آخرین ورژن ووکامرس 
* رابط کاربری و تنظیمات ساده و آسان 
* تنظیمات ارسال اطلاعات خریدار بصورت اختیاری


== Installation ==
1. فایل sn-woocommerce.zip را ازمنوی سایت گزینه " افزونه ها / افزودن / بارگذاری افزونه "  نصب کنید.
2. بعد از بارگذاری و نصب اولیه از منوی "افزونه ها" فعال سازی افزونه را انجام دهید.
3. سایر تنظیمات افزونه را میتوانید از طریق منوی ووکامرس "پیکربندی / تسویه حساب " در تب درگاه پرداخت و کیف پول الکترونیک انجام دهید. 

== Changelog ==

1.0.1 نسخه ی اولیه و بدون خطا افزونه پرداخت آنلاین 								