<?php

/*
Plugin Name: درگاه پرداخت و کیف پول الکترونیک  - افزونه WooCommerce

Version: 1.0.1
Description: تنظیمات درگاه پرداخت برای افزونه WooCommerce
Author:SN
*/

include_once('class-wc-gateway-sn.php');
