<?php

/*
Plugin Name: Woocommerce savano Gateway

Version: 1.0.1
Description: تنظیمات درگاه پرداخت برای افزونه WooCommerce
Author:Savano team
Plugin URI: http://savano.co.ir
*/

include_once('wc-gateway-sn.php');
